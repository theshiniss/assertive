library(testthat)
library(assertive.base)
library(assertive.reflection)

test_check("assertive.reflection")

