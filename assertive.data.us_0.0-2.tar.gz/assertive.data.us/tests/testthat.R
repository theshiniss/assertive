library(testthat)
library(assertive.data.us)

test_check("assertive.data.us")
