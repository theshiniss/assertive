## ---- Setup, echo = FALSE, results = "hide"-----------------------------------
set.seed(19790801)
library(assertive)
knitr::opts_chunk$set(error = FALSE)

