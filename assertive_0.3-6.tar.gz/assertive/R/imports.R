#' @import assertive.base
#' @import assertive.properties
#' @import assertive.types
#' @import assertive.numbers
#' @import assertive.strings
#' @import assertive.datetimes
#' @import assertive.files
#' @import assertive.sets
#' @import assertive.matrices
#' @import assertive.models
#' @import assertive.data
#' @import assertive.data.uk
#' @import assertive.data.us
#' @import assertive.reflection
#' @import assertive.code
#' @importFrom knitr opts_chunk
NULL

