library(testthat)
library(assertive.base)
library(assertive.code)

test_check("assertive.code")
