# assertive.code

## 0.0-4

- Fix issue with tests for `is_loaded()` in R 4.4.0.

## 0.0-3 

- Drop dependency on `devtools::with_envvar()`.
## 0.0-1 

- Content extracted from assertive 0.3-0, and tidied.
