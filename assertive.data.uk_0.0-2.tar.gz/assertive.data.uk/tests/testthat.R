library(testthat)
library(assertive.data.uk)

test_check("assertive.data.uk")
