library(testthat)
library(assertive.matrices)

test_check("assertive.matrices")
