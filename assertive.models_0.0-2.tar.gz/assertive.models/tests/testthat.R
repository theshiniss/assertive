library(testthat)
library(assertive.models)

test_check("assertive.models")
