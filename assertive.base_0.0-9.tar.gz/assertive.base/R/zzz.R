.onLoad <- function(libname, pkgname)
{
  options(assertive.severity = "stop")
}
