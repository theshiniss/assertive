library(testthat)
library(assertive.datetimes)

test_check("assertive.datetimes")
