library(testthat)
library(assertive.data)

test_check("assertive.data")
